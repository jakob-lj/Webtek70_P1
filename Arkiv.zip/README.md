Just another school project
